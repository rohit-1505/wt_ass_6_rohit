package com.bookstore.controller;

import com.bookstore.model.User;
import com.bookstore.repository.UserRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins={"http://localhost:5173","http://localhost:5174"})
public class UserController {
  private final UserRepository repo;
  public UserController(UserRepository repo){this.repo=repo;}

  @PostMapping("/register")
  public ResponseEntity<?> register(@RequestBody User u){
    if(repo.findByEmail(u.getEmail()).isPresent())
      return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("message","Email already registered"));
    return ResponseEntity.ok(repo.save(u));
  }

  @PostMapping("/login")
  public ResponseEntity<?> login(@RequestBody User u){
    return repo.findByEmail(u.getEmail())
      .filter(x -> x.getPassword().equals(u.getPassword()))
      .<ResponseEntity<?>>map(x -> ResponseEntity.ok(Map.of("message","Login successful","name",x.getName())))
      .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("message","Invalid email or password")));
  }
}
