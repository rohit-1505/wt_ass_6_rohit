package com.bookstore.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("books")
public class Book {
  @Id private String id;
  private String title;
  private String author;
  private String category;
  private double price;
  private String description;
  private String image;

  public Book() {}
  public Book(String title,String author,String category,double price,String description,String image){
    this.title=title;this.author=author;this.category=category;this.price=price;this.description=description;this.image=image;
  }
  public String getId(){return id;} public void setId(String id){this.id=id;}
  public String getTitle(){return title;} public void setTitle(String v){title=v;}
  public String getAuthor(){return author;} public void setAuthor(String v){author=v;}
  public String getCategory(){return category;} public void setCategory(String v){category=v;}
  public double getPrice(){return price;} public void setPrice(double v){price=v;}
  public String getDescription(){return description;} public void setDescription(String v){description=v;}
  public String getImage(){return image;} public void setImage(String v){image=v;}
}
