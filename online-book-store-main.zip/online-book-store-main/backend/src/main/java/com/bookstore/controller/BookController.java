package com.bookstore.controller;

import com.bookstore.model.Book;
import com.bookstore.repository.BookRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/books")
@CrossOrigin(origins={"http://localhost:5173","http://localhost:5174"})
public class BookController {
  private final BookRepository repo;
  public BookController(BookRepository repo){this.repo=repo;}
  @GetMapping public List<Book> all(){return repo.findAll();}
  @GetMapping("/{id}") public Book one(@PathVariable String id){return repo.findById(id).orElseThrow();}
  @PostMapping public Book add(@RequestBody Book b){return repo.save(b);}
}
