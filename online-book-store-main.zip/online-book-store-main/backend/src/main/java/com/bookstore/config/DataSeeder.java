package com.bookstore.config;

import com.bookstore.model.Book;
import com.bookstore.repository.BookRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSeeder {
  @Bean
  CommandLineRunner seed(BookRepository repo) {
    return args -> {
      if(repo.count()==0) {
        repo.save(new Book("The Psychology of Money","Morgan Housel","Business",399,"Timeless lessons on wealth, greed and happiness.","https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=500&q=80"));
        repo.save(new Book("Clean Code","Robert C. Martin","Programming",699,"A handbook of agile software craftsmanship.","https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=500&q=80"));
        repo.save(new Book("Atomic Habits","James Clear","Self Help",449,"Tiny changes that create remarkable results.","https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=500&q=80"));
        repo.save(new Book("The Alchemist","Paulo Coelho","Fiction",299,"A classic story about following your dreams.","https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=500&q=80"));
      }
    };
  }
}
