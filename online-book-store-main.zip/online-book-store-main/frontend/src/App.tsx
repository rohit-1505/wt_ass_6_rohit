import { useEffect, useMemo, useState } from 'react'
import { BookHeart, Search, ShoppingBag, User, Menu, X, Star, Heart, Sparkle, Plus, Minus, Trash2, LogOut } from 'lucide-react'

type Book = { id?: string; title: string; author: string; category: string; price: number; description: string; image: string }
type UserSession = { name: string; email: string }
type CartItem = Book & { quantity: number }

const API = 'http://localhost:8080/api'
const CART_KEY = 'booknest_cart'
const USER_KEY = 'booknest_user'

const fallbackBooks: Book[] = [
  {title:'The Psychology of Money',author:'Morgan Housel',category:'Business',price:399,description:'Timeless lessons on wealth, greed and happiness.',image:'https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=500&q=80'},
  {title:'Clean Code',author:'Robert C. Martin',category:'Programming',price:699,description:'A handbook of agile software craftsmanship.',image:'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=500&q=80'},
  {title:'Atomic Habits',author:'James Clear',category:'Self Help',price:449,description:'Tiny changes that create remarkable results.',image:'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=500&q=80'},
  {title:'The Alchemist',author:'Paulo Coelho',category:'Fiction',price:299,description:'A classic story about following your dreams.',image:'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=500&q=80'}
]

export default function App() {
  const [page,setPage] = useState<'home'|'catalogue'|'login'|'register'>('home')
  const [books,setBooks] = useState<Book[]>([])
  const [search,setSearch] = useState('')
  const [category,setCategory] = useState('All')
  const [cart,setCart] = useState<CartItem[]>(()=>JSON.parse(localStorage.getItem(CART_KEY)||'[]'))
  const [user,setUser] = useState<UserSession|null>(()=>JSON.parse(localStorage.getItem(USER_KEY)||'null'))
  const [cartOpen,setCartOpen] = useState(false)
  const [menu,setMenu] = useState(false)
  const [message,setMessage] = useState('')

  useEffect(()=>{fetch(`${API}/books`).then(r=>r.ok?r.json():Promise.reject()).then(setBooks).catch(()=>setBooks(fallbackBooks))},[])
  useEffect(()=>{localStorage.setItem(CART_KEY,JSON.stringify(cart))},[cart])
  useEffect(()=>{if(user)localStorage.setItem(USER_KEY,JSON.stringify(user));else localStorage.removeItem(USER_KEY)},[user])

  const categories = ['All', ...Array.from(new Set(books.map(b=>b.category)))]
  const filtered = useMemo(()=>books.filter(b=>(category==='All'||b.category===category)&&`${b.title} ${b.author}`.toLowerCase().includes(search.toLowerCase())),[books,category,search])
  const cartCount = cart.reduce((n,i)=>n+i.quantity,0)
  const total = cart.reduce((n,i)=>n+i.price*i.quantity,0)

  const addCart=(b:Book)=>setCart(c=>{const key=b.id||b.title; const found=c.find(x=>(x.id||x.title)===key); return found?c.map(x=>(x.id||x.title)===key?{...x,quantity:x.quantity+1}:x):[...c,{...b,quantity:1}]})
  const changeQty=(b:CartItem,delta:number)=>setCart(c=>c.map(x=>(x.id||x.title)===(b.id||b.title)?{...x,quantity:x.quantity+delta}:x).filter(x=>x.quantity>0))
  const remove=(b:CartItem)=>setCart(c=>c.filter(x=>(x.id||x.title)!==(b.id||b.title)))
  const logout=()=>{setUser(null);setMessage('Logged out successfully');setTimeout(()=>setMessage(''),2500)}

  return <div className="app">
    <header className="nav">
      <div className="brand" onClick={()=>setPage('home')}><BookHeart size={26}/><span>Book<em>Nest</em></span></div>
      <button className="mobile" onClick={()=>setMenu(!menu)}>{menu?<X/>:<Menu/>}</button>
      <nav className={menu?'open':''}>
        <button onClick={()=>{setPage('home');setMenu(false)}}>Home</button>
        <button onClick={()=>{setPage('catalogue');setMenu(false)}}>Catalogue</button>
        {user ? <><span className="welcome">Hi, {user.name}</span><button onClick={logout}><LogOut size={17}/> Logout</button></> : <button onClick={()=>{setPage('login');setMenu(false)}}><User size={17}/> Login</button>}
        <button className="cart" onClick={()=>setCartOpen(true)}><ShoppingBag size={18}/> {cartCount}</button>
      </nav>
    </header>

    {message && <div className="toast">{message}</div>}
    {page==='home' && <main>
      <section className="hero"><div><h1>Find your next<br/><em>cosy read</em></h1><p className="lead">A gentle little corner of the internet for stories, soft mornings and the books you'll dog-ear again and again.</p><button className="primary" onClick={()=>setPage('catalogue')}>Explore the catalogue</button></div><div className="hero-card"><Sparkle className="spark spark-1" size={18}/><Sparkle className="spark spark-2" size={14}/><BookHeart size={64}/><strong>Thousands of stories</strong><span>curated with a lot of heart</span></div></section>
      <section className="section"><div className="section-head"><div><h2>Featured this week</h2><p className="sub">A few of our favourites, picked with love</p></div><button onClick={()=>setPage('catalogue')} className="text-btn">View all</button></div><div className="grid">{books.slice(0,4).map(b=><BookCard key={b.id||b.title} b={b} add={()=>addCart(b)}/>)}</div></section>
      <section className="categories"><Heart size={22} fill="currentColor"/><h2>Browse by mood</h2><div>{categories.slice(1,6).map(c=><button key={c} onClick={()=>{setCategory(c);setPage('catalogue')}}>{c}</button>)}</div></section>
    </main>}
    {page==='catalogue' && <main className="section catalogue"><div className="section-head"><div><h2>The full shelf</h2><p className="sub">Every book we've got, all in one pretty place</p></div></div><div className="searchbar"><Search size={20}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by title or author..."/></div><div className="chips">{categories.map(c=><button className={category===c?'active':''} key={c} onClick={()=>setCategory(c)}>{c}</button>)}</div><div className="grid">{filtered.map(b=><BookCard key={b.id||b.title} b={b} add={()=>addCart(b)}/>)}</div>{!filtered.length&&<p className="empty">No books found — try a different search.</p>}</main>}
    {page==='login' && <Auth title="Welcome back" button="Login" onSwitch={()=>setPage('register')} onSuccess={(u)=>{setUser(u);setPage('home')}}/>}
    {page==='register' && <Auth title="Join the nest" button="Create account" onSwitch={()=>setPage('login')} register onSuccess={(u)=>{setUser(u);setPage('home')}}/>}
    <footer><BookHeart size={20}/> <span>BookNest · made with care, 2026</span></footer>
    {cartOpen && <Cart items={cart} total={total} onClose={()=>setCartOpen(false)} onChange={changeQty} onRemove={remove} onClear={()=>setCart([])} user={user} onLogin={()=>{setCartOpen(false);setPage('login')}}/>}
  </div>
}

function BookCard({b,add}:{b:Book,add:()=>void}) { return <article className="book"><img src={b.image} alt={b.title}/><div className="book-body"><span className="tag">{b.category}</span><h3>{b.title}</h3><p>{b.author}</p><div className="rating"><Star size={14} fill="currentColor"/> 4.8 <span>₹{b.price}</span></div><button onClick={add}>Add to cart</button></div></article> }

function Cart({items,total,onClose,onChange,onRemove,onClear,user,onLogin}:{items:CartItem[],total:number,onClose:()=>void,onChange:(b:CartItem,d:number)=>void,onRemove:(b:CartItem)=>void,onClear:()=>void,user:UserSession|null,onLogin:()=>void}) {
 return <div className="overlay" onClick={onClose}><aside className="cart-panel" onClick={e=>e.stopPropagation()}><div className="cart-head"><h2>Your Cart</h2><button onClick={onClose}><X/></button></div>{!items.length?<div className="empty-cart"><ShoppingBag size={48}/><h3>Your cart is empty</h3><p>Add a book from the catalogue.</p></div>:<><div className="cart-items">{items.map(i=><div className="cart-item" key={i.id||i.title}><img src={i.image} alt=""/><div className="cart-info"><h3>{i.title}</h3><p>₹{i.price}</p><div className="qty"><button onClick={()=>onChange(i,-1)}><Minus size={14}/></button><b>{i.quantity}</b><button onClick={()=>onChange(i,1)}><Plus size={14}/></button></div></div><button className="remove" onClick={()=>onRemove(i)}><Trash2 size={17}/></button></div>)}</div><div className="cart-bottom"><div><span>Total</span><strong>₹{total}</strong></div><button className="clear-btn" onClick={onClear}>Clear cart</button>{user?<button className="primary checkout" onClick={()=>alert(`Order placed successfully for ₹${total}!`)}>Place order</button>:<button className="primary checkout" onClick={onLogin}>Login to checkout</button>}</div></>}</aside></div>
}

function Auth({title,button,onSwitch,register=false,onSuccess}:{title:string,button:string,onSwitch:()=>void,register?:boolean,onSuccess:(u:UserSession)=>void}) {
 const [name,setName]=useState(''),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[loading,setLoading]=useState(false)
 const submit=async(e:React.FormEvent)=>{e.preventDefault();setError('');setLoading(true);try{const endpoint=register?'/users/register':'/users/login';const r=await fetch(`${API}${endpoint}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(register?{name,email,password}:{email,password})});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.message||'Request failed');onSuccess({name:data.name||name,email})}catch(err){setError(err instanceof Error?err.message:'Unable to connect to server. Make sure Spring Boot is running on port 8080.')}finally{setLoading(false)}}
 return <main className="auth"><form onSubmit={submit}><BookHeart size={34}/><h2>{title}</h2>{register&&<input required placeholder="Full name" value={name} onChange={e=>setName(e.target.value)}/>}<input required type="email" placeholder="Email address" value={email} onChange={e=>setEmail(e.target.value)}/><input required minLength={6} type="password" placeholder="Password (min 6 characters)" value={password} onChange={e=>setPassword(e.target.value)}/>{error&&<div className="auth-error">{error}</div>}<button disabled={loading} className="primary" type="submit">{loading?'Please wait...':button}</button><p>{register?'Already have an account?':'New to BookNest?'} <button type="button" className="link" onClick={onSwitch}>{register?'Login':'Create account'}</button></p></form></main>
}
