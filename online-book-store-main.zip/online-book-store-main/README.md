# Online Book Store

Stack: React + TypeScript + Spring Boot + MongoDB

## Requirements
- Node.js 20+
- JDK 21
- Maven 3.9+ (or use a Maven wrapper if added later)
- MongoDB Server running on localhost:27017

## Run frontend
cd frontend
npm install
npm run dev

## Run backend
cd backend
mvn spring-boot:run

Frontend: http://localhost:5173
Backend: http://localhost:8080

MongoDB database: bookstore
Collections: users, books

The backend seeds sample books automatically when the books collection is empty.
